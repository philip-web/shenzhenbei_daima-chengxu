#!/usr/bin/env python
# coding: utf-8

# In[15]:


from pyecharts.charts import Geo
from pyecharts.charts import Map
from pyecharts import options as opts
from pyecharts.globals import GeoType
import pandas as pd
help(opts.VisualMapOpts)
q = ["福田区","罗湖区","南山区","盐田区","宝安区","龙华区","光明区","龙岗区","坪山区","大鹏新区"]
# GDP_value = [552,600]
def test_geo():
    city = '深圳'
    g = Geo()
    g.add_schema(maptype=city,is_roam=True, label_opts=opts.LabelOpts(formatter=q))
    #增加区显示
#     g.add("",[list(z) for z in zip(cq_city, GDP_value)], "深圳", is_label_show=True,)
    # 设置样式
    g.set_series_opts(label_opts=opts.LabelOpts( is_show=False, position='bottom', font_size=10, color= '#FF6633',                                               font_style = 'italic' ,  font_weight = None))

    # 定义坐标对应的名称，添加到坐标库中 add_coordinate(name, lng, lat)
    data=pd.read_csv("E:/深圳杯/数据/深圳市各区养老机构情况表1.csv",encoding="gbk")
    d_d=data["地址"]
    d_lng=data["lng"]
    d_lat=data["lat"]
    d_chuang=data["年末床位数"]
    for i in range(len(d_d)):
        g.add_coordinate(str(d_d[i]),d_lng[i],d_lat[i])
        

    # 定义数据对，
    data_pair = [("深圳市福田区新沙路56号",420),("深圳市福田区园岭东路5号八角楼",162), ("深圳市福田区上步南路1001号锦峰大厦二楼",40), 
                 ("深圳市福田区梅林路133号2楼",50), ("深圳市福田区梅山苑二期6栋一楼",15), ("深圳市福田区田面花园4栋东一楼",29), 
                 ("深圳市福田区回雁路40号景龙大厦首层",32), ("深圳市福田区益田路益田村东广场三楼",75), ("深圳市福田保税区桂花苑一楼",50), 
                 ("深圳市福田区新洲路吉莲大厦3栋2楼",60), ("深圳市罗湖区太宁路73号",952), ("深圳市罗湖区红岗路1299号龙园山庄龙园大厦三楼",40), 
                 ("深圳市罗湖区黄贝岭中村89号2-10楼",122), ("深圳市盐田区盐田路2号",315), ("深圳市盐田区沙头角径口村63号",171), 
                 ("深圳市南山区龙苑路",800), ("深圳市南山区留仙大道7109号",992), ("深圳市南山区西丽同发路2号丽雅苑小区4栋1楼",60), 
                 ("深圳市南山区玉泉路22号",100), ("深圳市南山区四海路四海之家社区综合楼",160), ("深圳市南山区招商街道育才路7号",75), 
                 ("深圳市南山区后海滨路卓越维港名苑南区9-13栋1-48",100), ("深圳市宝安区黄田西部开发区",150), 
                 ("深圳市宝安区西乡街道铁岗水库路118号",98), ("深圳市宝安区福永街道福新街1号",80), ("深圳市宝安区沙井街道沙壆3路",98), 
                 ("深圳市宝安区松岗街道洋涌路26号",60), ("深圳市宝安区石岩街道州石公路任达山庄内",627), 
                 ("深圳市宝安区松岗街道松明大道179号",528), ("深圳市宝安区新安街道新安六路1099号",501), ("深圳市龙岗区横岗街道松柏路140号",40), 
                 ("深圳市龙岗区新生村龙河路6号",200), ("深圳市龙岗区龙岗街道南联社区龙溪路1号",196), 
                 ("深圳市龙岗区南联路46号地铁3号线南联站C2出口",600), ("深圳市龙岗区布吉镇龙岭东路福康街2号",88), 
                 ("深圳市龙岗区横岗镇富康路上围新村对面",30), ("深圳市龙岗区坪地街道崇德北路7号",0), 
                 ("深圳市龙岗区平湖街道上大街96号",0), ("深圳市龙华区观澜街道观光路旁",300), ("深圳市龙华办事处华联社区龙观西路桃苑新村100号",22), 
                 ("深圳市坪山区坑梓街道梓兴路55-1号",110), ("深圳市光明区光明街道光明大街150-6号",50), ("深圳市光明区公明办事处风景路49号",26),
                 ("深圳市大鹏新区南澳办事处枫南路1号",20), ("深圳市大鹏新区葵涌办事处葵坝路8号",20), ("深圳市大鹏新区大鹏办事处鹏新东路151号",43),
                 ("深圳市大鹏新区葵涌办事处金业路92号知己工业园",253), ("深圳市大鹏新区葵涌办事处溪涌村南一巷8-9号",300)]

   

    # Geo 图类型，有 scatter, effectScatter, heatmap, lines 4 种，建议使用
    # from pyecharts.globals import GeoType
    # GeoType.GeoType.EFFECT_SCATTER，GeoType.HEATMAP，GeoType.LINES

    # 将数据添加到地图上
    g.add('', data_pair, is_selected=True,type_=GeoType.EFFECT_SCATTER, symbol_size=5,label_opts="{b}"+"{c}")
    
    # 自定义分段 color 可以用取色器取色
    pieces = [
        {'max': 1, 'label': '0以下', 'color': '#50A3BA'},
        {'min': 1, 'max': 100, 'label': '1-100', 'color': '#3700A4'},
        {'min': 100, 'max': 200, 'label': '100-200', 'color': '#843900'},
        {'min': 200, 'max':300, 'label': '200-300', 'color': '#E2C568'},
        {'min': 300, 'max':400, 'label': '300-400', 'color': '#FCF84D'},
        {'min': 400, 'max': 500, 'label': '400-500', 'color': '#4172B8'},
        {'min': 500, 'max': 600, 'label': '500-600', 'color': '#F47920'},
        {'min': 600, 'max': 700, 'label': '600-700', 'color': '#EF5B9C'},
        {'min':700, 'max': 800, 'label': '700-800', 'color': '#7FB801'},
        {'min': 800, 'label': '800以上', 'color': '#D71345'}  # 有下限无上限
    ]
    #  is_piecewise 是否自定义分段， 变为true 才能生效
    g.set_global_opts(
        visualmap_opts=opts.VisualMapOpts(is_piecewise=True, pieces=pieces,pos_left=True),
        title_opts=opts.TitleOpts(title="{}市-养老院分布图".format(city),pos_top=True),
    )
    return g

g = test_geo()
# 渲染成html, 可用浏览器直接打开
g.render('E:/深圳杯/数据/深圳养老院.html')



